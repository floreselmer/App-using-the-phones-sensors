package com.example.sensorsurvey

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var mSensorManager: SensorManager
    private var mSensorProximity: Sensor? = null
    private var mSensorLight: Sensor? = null
    private var mSensorHumid: Sensor? = null

    private lateinit var mTextSensorLight: TextView
    private lateinit var mTextSensorProximity: TextView
    private lateinit var mTextSensorHumid: TextView








    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mSensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensorList = mSensorManager.getSensorList(Sensor.TYPE_ALL)




        mTextSensorLight = findViewById(R.id.label_light)
        mTextSensorProximity = findViewById(R.id.label_proximity)
        mTextSensorHumid = findViewById(R.id.label_humid)

        mSensorProximity = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        mSensorLight = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        mSensorHumid=mSensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY)



        val sensor_error = resources.getString(R.string.error_no_sensor)

        if (mSensorLight == null) {
            mTextSensorLight.text = sensor_error
        }

        if (mSensorProximity == null) {
            mTextSensorProximity.text = sensor_error
        }

        if (mSensorHumid == null) {
            mTextSensorHumid.text = sensor_error
        }


    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event != null) {
            val sensorType = event.sensor.type
            val currentValue = event.values[0]
            when (sensorType) {
                Sensor.TYPE_LIGHT ->
                    mTextSensorLight.text = resources.getString(R.string.label_light, currentValue)
                Sensor.TYPE_PROXIMITY ->
                    mTextSensorProximity.text = resources.getString(
                        R.string.label_proximity,
                        currentValue
                    )
                Sensor.TYPE_RELATIVE_HUMIDITY ->
                    mTextSensorHumid.text = resources.getString(
                        R.string.label_humid,
                        currentValue
                    )

                }
            }
        }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {

    }


    override fun onStart() {
        super.onStart()
        if (mSensorProximity != null) {
            mSensorManager.registerListener(
                this, mSensorProximity,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
        if (mSensorLight != null) {
            mSensorManager.registerListener(
                this, mSensorLight,
                SensorManager.SENSOR_DELAY_NORMAL
            )


        }


        if (mSensorHumid != null) {
            mSensorManager.registerListener(
                this, mSensorHumid,
                SensorManager.SENSOR_DELAY_NORMAL
            )


        }





    }

    override fun onStop() {
        super.onStop()
        mSensorManager.unregisterListener(this)
    }


}